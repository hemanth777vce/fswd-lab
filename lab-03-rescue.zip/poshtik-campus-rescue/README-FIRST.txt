============================================================
POSHTIK CAMPUS - LAB 3 RESCUE PACK
UI24PC520CS/521CS - FSWD - Vasavi College of Engineering
============================================================

READ THIS WHOLE FILE BEFORE TOUCHING ANYTHING ELSE.

------------------------------------------------------------
1. WHO THIS PACK IS FOR - AND WHO IT IS NOT FOR
------------------------------------------------------------
This pack is an EMERGENCY BRIDGE, nothing more. It exists for
exactly three situations:

  (a) your machine died / was replaced and you have no backup;
  (b) you were genuinely absent for Labs 1-2
      (with your instructor's knowledge);
  (c) your instructor explicitly told you to use it.

It is NOT for anyone who simply skipped the earlier labs.
Labs 1 and 2 are where you learned to WRITE this HTML - the
exams test that skill on paper, with no pack to rescue you.
Using this pack without genuine need does not save you work;
it only moves the work to the exam hall, where it costs marks.

TALK TO YOUR INSTRUCTOR BEFORE USING THIS PACK. No exceptions.

------------------------------------------------------------
2. STOP - THE BEST RESCUE IS NOT THIS PACK
------------------------------------------------------------
If you ever pushed your repo to GitHub (every lab since Lab 1
ends with a push), your real work is already safe. On any
machine:

    git clone https://github.com/<your-username>/poshtik-campus.git

That gives you YOUR pages and YOUR full commit history -
strictly better than anything in this folder. Only continue
below if you have no pushed repo to clone.

If your folder is fine and you only need the photos, take just
the images\ folder from this pack and skip everything else.

------------------------------------------------------------
3. WHAT THIS PACK RESTORES - IN PLAIN WORDS
------------------------------------------------------------
Lab 3 starts exactly where LAB 2 LEFT OFF:

  - Lab 1 built the three pages (index, menu, about).
  - Lab 2 grew menu.html: it gained the ORDER FORM
    ("Order Here", ten dish choices, quantity, notes).

This pack is that starting point, plus the photos Lab 3 needs:

    index.html    - Lab 1's front door, still plain. Lab 3's
                    Part 4 gives it its semantic skeleton.
    menu.html     - Lab 1's menu + Lab 2's order form. Lab 3's
                    Part 5 adds the header, the ten dish cards
                    and the footer.
    about.html    - Lab 1's about page, still plain. Lab 3's
                    Part 5 gives it the same skeleton.
    images\       - the logo AND all ten dish photos:
                    poshtik-campus-logo.jpg,
                    jonna-rotte-wrap.png, sajja-roti-wrap.png,
                    ragi-sangati-bowl.png, ragi-idli-bowl.jpg,
                    pesarattu-with-sprouts.jpg,
                    ulava-charu-protein-bowl.jpg,
                    gongura-sprouts-salad.jpg,
                    sprouts-moong-chilla.jpg,
                    paneer-protein-bowl.jpg,
                    millet-protein-shake.jpg

There is no style.css in this pack. You type it in Lab 3's
Part 5, like everyone else.

------------------------------------------------------------
4. SETUP - TEN MINUTES, IN THIS EXACT ORDER
------------------------------------------------------------
 1. Create the folder:  C:\Users\<you>\Desktop\poshtik-campus\
 2. Copy index.html, menu.html, about.html and the whole
    images\ folder into it. The images\ folder stays a folder
    INSIDE poshtik-campus\ - do not loose-copy the photos next
    to the html files.
 3. Open menu.html in the browser: a plain page with the list
    of ten dishes, the "Order Here" form below it, then the
    Home / About us links. No colours yet - that is correct.
 4. Make it a repo - ONE honest commit, exactly this message:

        git init
        git add .
        git commit -m "Catch up to Lab 3 starting point (rescue pack)"

 5. Create an empty GitHub repo named poshtik-campus, link and
    push (Lab 1 Part 19 shows the two commands). From today YOUR
    pushed repo is your insurance - this pack retires.

------------------------------------------------------------
5. THE HONEST SCAR - READ THIS TWICE
------------------------------------------------------------
Your classmates' git log shows two earned commits:

    9aec1d8 Add order form to menu      <- Lab 2's exit
    4806e56 Lab 1: three-page static site

Yours shows ONE rescue commit instead. That is deliberate.
We do not fake history in this course - a repo's log is its
autobiography, and yours honestly says "I caught up here."
Your Lab 3 commits will stack on top of the rescue commit, and
from here on your story is earned line by line like everyone
else's.

------------------------------------------------------------
6. THE DEBT - HOW TO ACTUALLY CATCH UP
------------------------------------------------------------
This pack restores FILES, not SKILLS. The skills live in the
sessions you missed, and every one is self-paced in Learning
Mode (scroll + sliders, no presenter needed):

    fswd_lab_01.html  - build pages like these from a blank file
    fswd_lab_02.html  - build the order form yourself (exam banker!)

Work through them this week, in a separate practice folder -
nothing you do there can damage this repo.

Now open fswd_lab_03.html, run Part 4's starting-line check,
and build the rest yourself.
============================================================
